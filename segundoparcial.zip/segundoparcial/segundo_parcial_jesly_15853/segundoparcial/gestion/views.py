from msilib.schema import ListView
from winreg import CreateKey, DeleteKey
from django.shortcuts import render
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.shortcuts import render, redirect
from .models import Profesor, Mascota
from .forms import ProfesorForm, MascotaForm # type: ignore

class ProfesorListView(LoginRequiredMixin, ListView):
    model = Profesor
    template_name = 'profesor_list.html'
    context_object_name = 'profesores'

class ProfesorCreateView(LoginRequiredMixin, UserPassesTestMixin, CreateKey):
    model = Profesor
    form_class = ProfesorForm
    template_name = 'profesor_form.html'
    success_url = '/profesores/'

    def test_func(self):
        return self.request.user.has_perm('gestion.add_profesor')

class ProfesorUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView): # type: ignore
    model = Profesor
    form_class = ProfesorForm
    template_name = 'profesor_form.html'
    success_url = '/profesores/'

    def test_func(self):
        return self.request.user.has_perm('gestion.change_profesor')

class ProfesorDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteKey):
    model = Profesor
    template_name = 'profesor_confirm_delete.html'
    success_url = '/profesores/'

    def test_func(self):
        return self.request.user.has_perm('gestion.delete_profesor')

# Repite el mismo proceso para Mascota
class MascotaListView(LoginRequiredMixin, ListView):
    model = Mascota
    template_name = 'mascota_list.html'
    context_object_name = 'mascotas'

# Agregar vistas para crear, actualizar y eliminar Mascota
# Create your views here.
