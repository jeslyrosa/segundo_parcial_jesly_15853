from django.apps import AppConfig
from django.contrib import admin
from .models import Profesor, Mascota

admin.site.register(Profesor)
admin.site.register(Mascota)

class GestionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gestion'
