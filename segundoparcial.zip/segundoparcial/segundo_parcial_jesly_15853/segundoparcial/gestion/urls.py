from django.urls import path
from .views import (
    ProfesorListView, ProfesorCreateView, ProfesorUpdateView, ProfesorDeleteView,
    MascotaListView, MascotaCreateView, MascotaUpdateView, MascotaDeleteView
)

urlpatterns = [
    path('profesores/', ProfesorListView.as_view(), name='profesor-list'),
    path('profesores/create/', ProfesorCreateView.as_view(), name='profesor-create'),
    path('profesores/<int:pk>/update/', ProfesorUpdateView.as_view(), name='profesor-update'),
    path('profesores/<int:pk>/delete/', ProfesorDeleteView.as_view(), name='profesor-delete'),

    path('mascotas/', MascotaListView.as_view(), name='mascota-list'),
    # Agrega las URLs para crear, actualizar y eliminar Mascota
]